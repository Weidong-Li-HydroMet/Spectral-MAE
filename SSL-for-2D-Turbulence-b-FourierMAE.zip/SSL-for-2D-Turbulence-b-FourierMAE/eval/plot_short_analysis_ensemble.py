# Read in short_analysis_results (rmse/acc/spectra) for different model realizations and
# plot 
